package com.taxpay.utils;

/**
 * @author M1064394
 *
 */
/**
 * @author M1064394
 *
 */
public enum ErrorCode {

	/**
	 * 
	 */
	RECORD_NOT_FOUND("TPA-RNF-001", "Record not found"),
	
	/**
	 * 
	 */
	RECORD_FETCH_EXCEPTION("TPA-RFE-002", "Error occured while fetching records"),
	
	
	/**
	 * 
	 */
	RECORD_NOT_SAVED("TPA-RNS-003", "Error occured while persisting records into database")
;

	private final String errorCode;

	
	private final String errorMessage;

	/**
	 * Constructor of ErrorCode
	 * 
	 * @param errorCode
	 * @param errorMessage
	 */
	private ErrorCode(final String errorCode, final String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	/**
	 * @return - the Error code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @return the Error Message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

}
