package com.taxpay.utils;

public class TaxPayException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public TaxPayException() {
		super();
	}
	public TaxPayException(String message) {
		super(message);
	}
	
	public TaxPayException(String errorCode, String message) {
		//super(errorCode, message);
	}

	public TaxPayException(Throwable cause) {
		super(cause);
	}

}
