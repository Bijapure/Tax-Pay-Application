package com.taxpay.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UnitArea {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer unitAreaId;
	
	private Float unitAreaValue;
	
	@JoinColumn(name = "zoneId", referencedColumnName = "zoneId")
	@ManyToOne(cascade = CascadeType.ALL)
	private ZoneClassfication zonalClassification;
	
	@JoinColumn(name = "categoryId", referencedColumnName = "propertyId")
	@ManyToOne(cascade = CascadeType.ALL)
	private PropertyCategory descOfProperty;
	
	@JoinColumn(name = "statusId", referencedColumnName = "statusId")
	@ManyToOne(cascade = CascadeType.ALL)
	private BuildingStatus status;
	
}
