package com.taxpay.service.Impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.taxpay.dao.PropertyCategoryDao;
import com.taxpay.dao.TaxDAO;
import com.taxpay.dto.PropertyCategoryDTO;
import com.taxpay.dto.TaxDTO;
import com.taxpay.entity.PropertyCategory;
import com.taxpay.entity.Tax;
import com.taxpay.exception.DAOException;
import com.taxpay.service.TaxService;
import com.taxpay.utils.ErrorCode;

import lombok.extern.log4j.Log4j2;

@Service("taxService")
@Log4j2
public class TaxServiceImpl implements TaxService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private TaxDAO taxDAO;

	@Autowired
	private PropertyCategoryDao descOfPropertyDto;

	/**
	 * @param taxDto
	 */
	@Override
	@Transactional(isolation = Isolation.SERIALIZABLE)
	public void saveCalculatedTaxDetails(TaxDTO taxDto) {
		log.info("TaxServiceImpl Started :: calculateTaxPayAmount");
		Tax taxData = modelMapper.map(taxDto, Tax.class);
		if (taxData != null)
			taxDAO.saveAndCalculateTax(taxData);
	}

	/**
	 * @param taxDto
	 * @return
	 */
	@Override
	@Transactional
	public TaxDTO calculatePayableTaxAmount(TaxDTO taxDto) {
		log.info("TaxServiceImpl", "calculatePayableTaxAmount");
		Tax taxData = modelMapper.map(taxDto, Tax.class);
		Tax tax = taxDAO.calculatePayableTaxAmount(taxData);
		return modelMapper.map(tax, TaxDTO.class);
	}

	/**
	 * @param descOfProperty
	 */
	@Override
	@Transactional(isolation = Isolation.SERIALIZABLE)
	public void addPropertyCategory(PropertyCategoryDTO descOfProperty) {
		log.info("TaxServiceImpl", "addPropertyCategory");
		try {
			PropertyCategory descOfPropData = modelMapper.map(descOfProperty, PropertyCategory.class);
			if(descOfPropData.getDescOfProperty()!=null || !descOfPropData.getDescOfProperty().equalsIgnoreCase(null))
			descOfPropertyDto.createAndSavePropDesc(descOfPropData);
		} catch (DAOException data) {
			log.error(ErrorCode.RECORD_NOT_SAVED.getErrorCode(), ErrorCode.RECORD_NOT_SAVED.getErrorMessage());
			throw new DAOException(ErrorCode.RECORD_NOT_SAVED.getErrorCode(),
					ErrorCode.RECORD_NOT_SAVED.getErrorMessage());
		}
	}

	/**
	 * @return
	 */
	@Override
	@Transactional
	public List<PropertyCategory> getalldescofproperty() {
		log.info("TaxServiceImpl", "addPropertyCategory");
			return descOfPropertyDto.findAllDescOfProperty();
	}

	/**
	 * @param zone
	 * @param status
	 * @return
	 */
	@Override
	@Transactional
	public Float zonalwisereport(String status, String zone) {
		log.info("TaxServiceImpl", "zonalwisereport");
		return taxDAO.zonalwisereport(status, zone);
	}

}
