package com.taxpay.service;

import java.util.List;

import javax.validation.Valid;

import com.taxpay.dto.PropertyCategoryDTO;
import com.taxpay.dto.TaxDTO;
import com.taxpay.entity.PropertyCategory;

/**
 * @author M1064394
 *
 */
public interface TaxService {

	/**
	 * @param taxDto
	 */
	void saveCalculatedTaxDetails(TaxDTO taxDto);

	/**
	 * @param taxDto
	 * @return 
	 */
	TaxDTO calculatePayableTaxAmount(@Valid TaxDTO taxDto);

	/**
	 * @param descOfProperty
	 */
	void addPropertyCategory(@Valid PropertyCategoryDTO descOfProperty);

	/**
	 * @return
	 */
	List<PropertyCategory> getalldescofproperty();

	/**
	 * @param status
	 * @param zone
	 * @return
	 */
	Float zonalwisereport(String status, String zone);
	
	

}
