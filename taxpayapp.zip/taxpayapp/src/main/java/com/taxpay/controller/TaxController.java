package com.taxpay.controller;
//http://websystique.com/
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.taxpay.dao.Impl.BuildingStatusRepository;
import com.taxpay.dao.Impl.TaxRepository;
import com.taxpay.dao.Impl.ZoneClassficationRepository;
import com.taxpay.dto.PropertyCategoryDTO;
import com.taxpay.dto.TaxDTO;
import com.taxpay.entity.BuildingStatus;
import com.taxpay.entity.PropertyCategory;
import com.taxpay.entity.ZoneClassfication;
import com.taxpay.service.TaxService;

/**
 * @author M1064394
 *
 */
@Controller
public class TaxController {

	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	public TaxService taxService;
	
	@Autowired
	public TaxRepository taxRepo;

	@Autowired
	public ZoneClassficationRepository zoneClassesRepo;
	
	@Autowired
	public BuildingStatusRepository buildStatusRepo;
	
	@GetMapping("/taxDetail")
	public String taxDetail() {
		return "taxDetail";
	}

	// for save calculated tax
	@RequestMapping("/savecalculatetax")
	public String savecalculatetax(@Valid TaxDTO taxDto) {
		taxService.saveCalculatedTaxDetails(taxDto);
		return "index";
	}

	@RequestMapping("/calculatetax")
	public ModelAndView calculatetax(TaxDTO taxDto) {
		ModelAndView mv = new ModelAndView("calculatetax");
		TaxDTO st = this.taxService.calculatePayableTaxAmount(taxDto);
		mv.addObject("st", st);
		return mv;
	}

	// adding category of bulding e.g. RCC Building
	@PostMapping("/addPropertyCategory")
	public ResponseEntity<String> addPropertyCategory(@Valid @RequestBody PropertyCategoryDTO descOfProperty) {
		taxService.addPropertyCategory(descOfProperty);
		return ResponseEntity.ok().header("status:", "200").body("Description: Property Category successfully saved");
	}

	// get details of all the property building category in dropdown
	@GetMapping("/taxform")
	public ModelAndView getalldescofproperty() {
		ModelAndView mv = new ModelAndView("taxform");
		List<PropertyCategory> st = this.taxService.getalldescofproperty();
		List<ZoneClassfication> zc=this.zoneClassesRepo.findAll();
		List<BuildingStatus> bs=this.buildStatusRepo.findAll();
		mv.addObject("st", st);
		mv.addObject("zc",zc);
		mv.addObject("bs",bs);
		return mv;
	}

	@RequestMapping("/zonalwisereport")
	public ModelAndView zonalwisereport()
	{
		ModelAndView mv= new ModelAndView("zonalwisereport");
		Float zoneAOwner=this.taxService.zonalwisereport("Owner","zone A");
		mv.addObject("zoneAOwner", zoneAOwner);
		Float zoneATenanted=this.taxService.zonalwisereport("Tenanted","zone A");
		mv.addObject("zoneATenanted", zoneATenanted);
		
		Float zoneBOwner=this.taxService.zonalwisereport("Owner","zone B");
		mv.addObject("zoneBOwner", zoneBOwner);
		Float zoneBTenanted=this.taxService.zonalwisereport("Tenanted","zone B");
		mv.addObject("zoneBTenanted", zoneBTenanted);
		
		Float zoneCOwner=this.taxService.zonalwisereport("Owner","zone C");
		mv.addObject("zoneCOwner", zoneCOwner);
		Float zoneCTenanted=this.taxService.zonalwisereport("Tenanted","zone C");
		mv.addObject("zoneCTenanted", zoneCTenanted);
		
		return mv;
	}
}
