package com.taxpay.exception;

import com.taxpay.utils.TaxPayException;

public class DAOException extends TaxPayException {

	/**
	 * if topic for user are not found 
	 */
	private static final long serialVersionUID = 1L;
	
	public DAOException(String message)
	{
		super(message);
	}

	public DAOException(String error,String message)
	{
		super(error,message);
	}
	
}
