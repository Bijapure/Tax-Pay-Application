package com.taxpay.exception;

import com.taxpay.utils.TaxPayException;

public class RecordsNotFoundException extends TaxPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;
	public RecordsNotFoundException(String message) {
		//super(message);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
