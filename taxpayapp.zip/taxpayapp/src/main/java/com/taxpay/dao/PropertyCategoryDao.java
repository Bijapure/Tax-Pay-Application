package com.taxpay.dao;

import java.util.List;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.taxpay.dao.Impl.PropertyCategoryRepository;
import com.taxpay.entity.PropertyCategory;
import com.taxpay.exception.DAOException;

@Component
public class PropertyCategoryDao {

	@Autowired
	public PropertyCategoryRepository propCateRepo;

	public void createAndSavePropDesc(PropertyCategory descOfPropData) {

		if (descOfPropData != null) {
			propCateRepo.save(descOfPropData);
		} else
			throw new ValidationException("Property Desc dont have any data !!!!");
	}

	public List<PropertyCategory> findAllDescOfProperty() {
		try {
			List<PropertyCategory> descOfCategoryList = propCateRepo.findAll();
			return descOfCategoryList;
		} catch (DAOException e) {
			throw new DAOException("DB returns No records " + e.getMessage());
		}
	}

}
