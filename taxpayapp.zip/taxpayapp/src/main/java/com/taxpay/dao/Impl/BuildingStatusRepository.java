package com.taxpay.dao.Impl;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taxpay.entity.BuildingStatus;

public interface BuildingStatusRepository extends JpaRepository<BuildingStatus, Integer> {

	
}
