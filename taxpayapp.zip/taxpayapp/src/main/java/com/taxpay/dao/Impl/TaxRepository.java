package com.taxpay.dao.Impl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.taxpay.entity.Tax;

/**
 * @author M1064394
 *
 */
@Repository("taxRepository")
public interface TaxRepository extends JpaRepository<Tax, Integer> {

	@Query(value = "\r\n"
			+ "select sum(t.total_tax) from tax t inner join zone_classfication z on z.zone_id=t.zone_id\r\n"
			+ "inner join building_status b on \r\n"
			+ "t.status_id=b.status_id where b.status=:status and z.zonal_classification=:zone", nativeQuery = true)
	Float getzonalwiseReport(String status, String zone);

}
