package com.taxpay.dao.Impl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.taxpay.entity.UnitArea;

public interface UnitAreaRepository extends JpaRepository<UnitArea, Integer> {

	@Query(value = "select u.unit_area_value from unit_area u where u.category_id=:propertyId and u.zone_id=:zoneId and u.status_id=:statusId", nativeQuery = true)
	Integer getUnitAreaValue(Integer propertyId, Integer zoneId, Integer statusId);

}
