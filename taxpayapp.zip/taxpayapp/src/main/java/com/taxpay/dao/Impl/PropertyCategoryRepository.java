package com.taxpay.dao.Impl;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taxpay.entity.PropertyCategory;

public interface PropertyCategoryRepository extends JpaRepository<PropertyCategory, Integer> {

}
