package com.taxpay.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.taxpay.dao.Impl.BuildingStatusRepository;
import com.taxpay.dao.Impl.PropertyCategoryRepository;
import com.taxpay.dao.Impl.TaxRepository;
import com.taxpay.dao.Impl.UnitAreaRepository;
import com.taxpay.dao.Impl.ZoneClassficationRepository;
import com.taxpay.entity.BuildingStatus;
import com.taxpay.entity.PropertyCategory;
import com.taxpay.entity.Tax;
import com.taxpay.entity.ZoneClassfication;
import com.taxpay.exception.DAOException;
import com.taxpay.exception.RecordsNotFoundException;
import com.taxpay.utils.ErrorCode;

import lombok.extern.log4j.Log4j2;

/**
 * @author M1064394
 *
 */
@Component
@Log4j2
public class TaxDAO {

	@Autowired
	private TaxRepository taxRepository;

	@Autowired
	private PropertyCategoryRepository propRepo;

	@Autowired
	public ZoneClassficationRepository zoneClassesRepo;

	@Autowired
	public BuildingStatusRepository buildStatusRepo;

	@Autowired
	public UnitAreaRepository unitAreaRepo;

	private ZoneClassfication zoneClassification = null;
	private PropertyCategory propertyDescription = null;
	private BuildingStatus status = null;

	/**
	 * @param taxData
	 */
	public void saveAndCalculateTax(Tax taxData) {
		log.info("TaxDAO started :: saveAndCalculateTax");
		try {
			taxData.setDescOfProperty(propertyDescription);
			taxData.setZonalClassification(zoneClassification);
			taxData.setStatus(status);
			taxRepository.save(taxData);
		} catch (DAOException ex) {
			throw new DAOException(ErrorCode.RECORD_NOT_SAVED.getErrorCode(),
					ErrorCode.RECORD_NOT_SAVED.getErrorMessage());
		}
	}

	/**
	 * @param taxData
	 * @return
	 */
	public Tax calculatePayableTaxAmount(Tax taxData) {
		log.info("TaxDAO started :: calculatePayableTaxAmount");
		try {

			Integer unitArea = calculateUnitArea(taxData);
			Integer total_1 = taxData.getBuildUpArea() * unitArea * 10;
			Integer depreciation = (2021) - (taxData.getBuildConstructYear());

			Float total_2 = 0f;
			if (depreciation == 100) {
				total_2 = (float) total_1 - (60 / 100);
			} else {
				Float val = (float) depreciation / 100;
				total_2 = (total_1) - (val);
			}
			Float total_3 = 0f;
			total_3 = total_2 * (0.2f);
			Float total_4 = total_3 * (0.24f);
			Float total_5 = (total_3 + total_4);
			taxData.setTotalTax(total_5);
			return taxData;
		} catch (DAOException ex) {
			throw new DAOException(ErrorCode.RECORD_FETCH_EXCEPTION.getErrorCode(),
					ErrorCode.RECORD_FETCH_EXCEPTION.getErrorMessage());
		}
	}

	/**
	 * @param taxData
	 * @return
	 */
	private Integer calculateUnitArea(Tax taxData) {
		try {
			List<PropertyCategory> propDescList = propRepo.findAll();
			Optional<PropertyCategory> propData = propDescList.stream().filter(
					prop -> prop.getDescOfProperty().equalsIgnoreCase(taxData.getDescOfProperty().getDescOfProperty()))
					.findFirst();

			List<ZoneClassfication> zoneList = zoneClassesRepo.findAll();
			Optional<ZoneClassfication> zoneData = zoneList.stream().filter(zone -> zone.getZonalClassification()
					.equalsIgnoreCase(taxData.getZonalClassification().getZonalClassification())).findFirst();

			List<BuildingStatus> statusList = buildStatusRepo.findAll();
			Optional<BuildingStatus> statusData = statusList.stream()
					.filter(status -> status.getStatus().equalsIgnoreCase(taxData.getStatus().getStatus())).findFirst();

			Integer unitAreaValue = unitAreaRepo.getUnitAreaValue(propData.get().getPropertyId(),
					zoneData.get().getZoneId(), statusData.get().getStatusId());

			zoneClassification = zoneData.get();
			propertyDescription = propData.get();
			status = statusData.get();
			return unitAreaValue;
		} catch (DAOException ex) {
			throw new RecordsNotFoundException(ErrorCode.RECORD_FETCH_EXCEPTION.getErrorMessage());
		}
	}

	/**
	 * @param status
	 * @param zone
	 * @return
	 */
	public Float zonalwisereport(String status, String zone) {
		try {
			Float zoneWiseValue = taxRepository.getzonalwiseReport(status, zone);
			return zoneWiseValue;
		} catch (DAOException ex) {
			throw new DAOException(ErrorCode.RECORD_FETCH_EXCEPTION.getErrorCode() + " :: "
					+ ErrorCode.RECORD_FETCH_EXCEPTION.getErrorMessage());
		}
	}

}
