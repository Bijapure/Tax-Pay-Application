package com.taxpay.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author M1064394
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxDTO {

	private Integer taxId;
	@NotNull(message = "Year can not be empty")
	private Integer yearOfAssessment;

	@NotEmpty(message = "Name can not be empty")
	private String nameOfOwner;

	@NotEmpty(message = "email can not be empty")
	private String email;

	@NotEmpty(message = "addressOfProperty can not be empty")
	private String addressOfProperty;

	@NotEmpty(message = "zonalClassification can not be empty")
	private String zonalClassification;

	@NotNull(message = "descOfProperty can not be empty")
	private String descOfProperty;

	@NotNull(message = "status can not be empty")
	private String status;

	@NotNull(message = "buildConstructYear can not be empty")
	private Integer buildConstructYear;

	@NotNull(message = "buildUpArea can not be empty")
	private Integer buildUpArea;

	@NotNull(message = "totalTax can not be empty")
	private Float totalTax;

}
