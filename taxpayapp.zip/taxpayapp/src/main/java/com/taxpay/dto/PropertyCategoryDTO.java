package com.taxpay.dto;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class PropertyCategoryDTO {
	
	private Integer propertyId;
	@NotEmpty(message = "descOfProperty can't be empty")
	private String descOfProperty;

}
