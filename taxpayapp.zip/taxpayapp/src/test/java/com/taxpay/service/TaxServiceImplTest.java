package com.taxpay.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.opentest4j.AssertionFailedError;
import org.springframework.boot.test.context.SpringBootTest;

import com.taxpay.dao.TaxDAO;
import com.taxpay.dto.TaxDTO;
import com.taxpay.entity.Tax;
import com.taxpay.exception.DAOException;
import com.taxpay.service.Impl.TaxServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class TaxServiceImplTest {

	@InjectMocks
	TaxServiceImpl taxService;

	@Mock
	private ModelMapper modelMapper;

	@Mock
	TaxDAO taxDao;

	@Test
	public void calculatePayableTaxAmountTest() {
		when(taxDao.calculatePayableTaxAmount(gettaxData())).thenReturn(gettaxData());
		taxService.calculatePayableTaxAmount(getTaxDto());
		assertEquals("abc@gmail.com", getTaxDto().getEmail());

	}

	@Test(expected = DAOException.class)
	public void calculatePayableTaxAmountFailureTest() {
		when(taxDao.calculatePayableTaxAmount(gettaxData())).thenReturn(gettaxData());
		taxService.calculatePayableTaxAmount(getTaxDto());
		assertEquals("abc@gmail.com", getTaxDto().getEmail());

	}

	@Test
	public void saveCalculatedTaxDetailsTest() {
		taxService.saveCalculatedTaxDetails(getTaxDto());
	}

	@Test(expected = DAOException.class)
	public void saveCalculatedTaxDetailsFailTest() {
		taxService.saveCalculatedTaxDetails(getTaxDto());
	}

	@Test
	public void zonalwisereportTest() {
		when(taxDao.zonalwisereport("Tenanted", "zone A")).thenReturn(2144.56f);
		Float taxAmount = taxDao.zonalwisereport("Tenanted", "zone A");
		assertEquals(2144.56f, taxAmount);
	}

	@Test(expected = DAOException.class)
	public void zonalwisereportFailTest() {
		when(taxDao.zonalwisereport("Tenanted", "zone A")).thenReturn(2144.56f);
		Float taxAmount = taxDao.zonalwisereport("Tenanted", "zone A");
		assertNotEquals(2144.56f, taxAmount);
		}

	public Tax gettaxData() {
		Tax tax = new Tax();
		tax.setEmail("abc@gmail.com");
		return tax;
	}

	public TaxDTO getTaxDto() {
		TaxDTO tax = new TaxDTO();
		tax.setEmail("abc@gmail.com");
		return tax;
	}

}
