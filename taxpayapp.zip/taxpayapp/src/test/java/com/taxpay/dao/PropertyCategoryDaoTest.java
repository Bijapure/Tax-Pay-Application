package com.taxpay.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import com.taxpay.dao.Impl.PropertyCategoryRepository;
import com.taxpay.entity.PropertyCategory;
import com.taxpay.exception.DAOException;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class PropertyCategoryDaoTest {

	@Mock
	PropertyCategoryRepository pcr;

	@InjectMocks
	PropertyCategoryDao pcd;

	@Test
	public void findAllDescOfPropertyTest() {
		when(pcr.findAll()).thenReturn(getPropCategoryList());
		List<PropertyCategory> pcList = pcd.findAllDescOfProperty();
		assertEquals(1, pcList.size());

	}

	@Test(expected = DAOException.class)
	public void findAllDescOfPropertyTestWithFailure() {
		when(pcr.findAll()).thenReturn(getPropCategoryList());
		pcr.deleteAll();
		List<PropertyCategory> pcList = pcd.findAllDescOfProperty();
		assertEquals(2, pcList.size());
	}

	public List<PropertyCategory> getPropCategoryList() {
		PropertyCategory pc = new PropertyCategory();
		pc.setPropertyId(1);
		pc.setDescOfProperty("RCC Building");
		return Arrays.asList(pc);
	}

}
